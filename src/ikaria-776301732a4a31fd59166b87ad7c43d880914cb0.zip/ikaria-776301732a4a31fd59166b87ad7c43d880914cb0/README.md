# arboria
simple exploration and building game

i started making arboria after i realized i can make games that 
**i** want to play and not games that others want to play.

## do:
- before starting, strip down and modularize doodle-duels into easy game library
- start project with the library as a base
- make player
- make world
- tiles:
    - grass
    - stone
    - sand
    - water
    - basalt
    - lava

## doing:

## done:

