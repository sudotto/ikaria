#ifndef GAME_INFO
#define GAME_INFO

#define GAME_W 900
#define GAME_H 600

#define CAM_X 0
#define CAM_Y 0
#define CAM_SCALE 1

#endif
