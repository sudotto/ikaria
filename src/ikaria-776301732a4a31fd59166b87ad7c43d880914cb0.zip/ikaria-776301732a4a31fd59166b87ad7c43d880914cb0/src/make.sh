gcc main.c player.c world.c otto-game.c -o app -lSDL3 -lSDL3_image -lm -g 
